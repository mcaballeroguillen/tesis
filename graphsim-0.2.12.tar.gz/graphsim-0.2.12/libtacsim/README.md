#libtacsim

C implementation of TACSim algorithm.


## Compile

Install [Scons](http://www.scons.org/) and run `scons` under the folder of this file.

## Installed Path

Library file is intalled to `/usr/local/lib` and header file to ``/usr/local/include`.