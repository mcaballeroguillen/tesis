from linear_threshold import *
from independent_cascade import *
